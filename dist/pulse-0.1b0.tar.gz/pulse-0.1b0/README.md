# Pulse
Code used to simulate pulse response sensitivity to regulatory perturbations under varied biosynthesis conditions.
