
a = 1
job_script = open('./test.sh', 'w')
job_script.write('python scripts/run.py ${PATH}')
job_script.write(' -D {:d}\n'.format(a))
job_script.write('`\n\n')
job_script.close()
