from argparse import ArgumentParser

parser = ArgumentParser(description='Run a perturbation simulation.')

# simulation directory
parser.add_argument('path', nargs=1)

args = vars(parser.parse_args())

print(args['path'][0])
