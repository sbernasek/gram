# GRAM
Code used to simulate pulse response sensitivity to gene regulatory perturbations under varied biosynthesis conditions.
